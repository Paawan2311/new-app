from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

DB_FILE = "students.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            class TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

def insert_student(name, student_class):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO students (name, class) VALUES (?, ?)", (name, student_class))
    conn.commit()
    conn.close()

@app.route("/")
def home():
    return "Backend is running! Use /api/add-student to POST student data."

@app.route("/api/add-student", methods=["POST"])
def add_student():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid JSON"}), 400

    name = data.get("name")
    student_class = data.get("class")

    if not name or not student_class:
        return jsonify({"error": "Missing 'name' or 'class'"}), 400

    insert_student(name, student_class)
    return jsonify({"message": f"Student {name} in class {student_class} added successfully"}), 201

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5001)
