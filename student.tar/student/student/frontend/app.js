document.getElementById("studentForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const studentClassValue = document.getElementById("class").value;

    fetch("http://127.0.0.1:5001/api/add-student", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name, class: studentClassValue })
    })
    .then(res => {
        if (!res.ok) {
            throw new Error(`Server error: ${res.status}`);
        }
        return res.json();
    })
    .then(data => {
        document.getElementById("response").textContent = data.message || data.error;
    })
    .catch(err => {
        document.getElementById("response").textContent = `Error: ${err.message}`;
        console.error(err);
    });
});
